package com.redbus.commonUtilities;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelUtils {
    private static Workbook workbook;
    private static Sheet sheet;

    public static void setExcelFile() throws IOException {
        FileInputStream fileInputStream = new FileInputStream("/test/resources/TestData.xlsx");
        workbook = new XSSFWorkbook(fileInputStream);
        sheet = workbook.getSheet("Sheet1");
    }

    public static String getCellData(int rowNum, int colNum) {
        Cell cell = sheet.getRow(rowNum).getCell(colNum);
        if (cell == null) {
            return ""; // Return empty string if cell is empty
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                // You can handle formula cells as needed
                return cell.getCellFormula();
            default:
                return ""; // Return empty string for unsupported cell types
        }
    }

    public static void setCellData(int rowNum, int colNum, String data) throws IOException {
        Row row = sheet.getRow(rowNum);
        if (row == null) {
            row = sheet.createRow(rowNum);
        }
        Cell cell = row.createCell(colNum);
        cell.setCellValue(data);

        FileOutputStream fileOutputStream = new FileOutputStream("Output.xlsx");
        workbook.write(fileOutputStream);
        fileOutputStream.close();
    }

    public static int getRowCount() {
        return sheet.getLastRowNum() - sheet.getFirstRowNum();
    }

    public static int getColumnCount() {
        return sheet.getRow(0).getLastCellNum();
    }
}
