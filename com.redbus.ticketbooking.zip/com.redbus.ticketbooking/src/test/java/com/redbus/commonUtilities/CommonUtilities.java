package com.redbus.commonUtilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;


import io.github.bonigarcia.wdm.WebDriverManager;

public class CommonUtilities {

	public static Properties properties = null;
	public static WebDriver driver = null;

	Logger logger = Logger.getLogger(CommonUtilities.class);
	public Properties loadPropertyFile() {
		try {
			FileInputStream fileInputStream = new FileInputStream("config.properties");
			properties = new Properties();
			properties.load(fileInputStream);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		return properties;
	}

	@BeforeSuite
	public void launchBrowser() {
		try {
		PropertyConfigurator.configure("log4j2.properties");
		logger.info("Red Bus Ticket Booking");
		logger.info("Loading the Property file");
		loadPropertyFile();
		String browser = properties.getProperty("browser");
		String url = properties.getProperty("url");
//		String driverLocation = properties.getProperty("DriverLocation");

		
			switch (browser) {
			case "chrome":
				WebDriverManager.chromedriver().setup();
				logger.info("Launching"+browser);
				driver=new ChromeDriver();
				break;
			case "firefox":
				WebDriverManager.firefoxdriver().setup();
				logger.info("Launching"+browser);
				driver = new FirefoxDriver();
				break;
			case "edge":
				WebDriverManager.edgedriver().setup();
				logger.info("Launching"+browser);
				driver = new EdgeDriver();
				break;
			case "ie":
				WebDriverManager.iedriver().setup();
				logger.info("Launching"+browser);
				driver = new InternetExplorerDriver();
				break;

			default:
				WebDriverManager.chromedriver().setup();
				logger.info("Launching"+browser);
				driver=new ChromeDriver();
				break;
			}
			
			driver.manage().window().maximize();
			driver.get(url);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

	@AfterSuite
	public void tearDown() {
		driver.quit();
	}
}
