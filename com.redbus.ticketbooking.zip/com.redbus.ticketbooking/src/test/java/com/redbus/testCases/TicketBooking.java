package com.redbus.testCases;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.redbus.commonUtilities.CommonUtilities;
import com.redbus.commonUtilities.ExcelUtils;
import com.redbus.pageObjects.FilterPageObjects;
import com.redbus.pageObjects.HomePageObjects;
import com.redbus.pageObjects.PassengerDetailsPageObjects;
import com.redbus.pageObjects.SeatsPageObjects;

public class TicketBooking extends CommonUtilities {

	public void chooseLocation(String from) {
		PageFactory.initElements(driver, HomePageObjects.class);
		HomePageObjects.fromLocation.sendKeys(from);
		HomePageObjects.locationSelector.click();
		HomePageObjects.toLocation.sendKeys("Pondicherry");
		HomePageObjects.locationSelector.click();
		HomePageObjects.calender.click();
		HomePageObjects.date.click();
		HomePageObjects.searchBusesButton.click();
	}

	public void setFilterAndBusCount() {

		PageFactory.initElements(driver, FilterPageObjects.class);
		FilterPageObjects.before6AMFilter.click();
		FilterPageObjects.seaterFilter.click();
		String busCount = FilterPageObjects.busCount.getText();
		System.out.println("Number of buses available : " + busCount);
		FilterPageObjects.viewSeats.click();
	}
	
	public void getBusCount() {

		PageFactory.initElements(driver, FilterPageObjects.class);
		String busCount = FilterPageObjects.noBus.getText();
		System.out.println("Number of buses available : " + busCount);
		
	}

	public void seatSelection() {
		PageFactory.initElements(driver, SeatsPageObjects.class);

		// Coordinates to click within the canvas
		int x = 464; // Adjust X coordinate as needed
		int y = 112; // Adjust Y coordinate as needed

		// Execute JavaScript to simulate a click at the specified coordinates
		String script = "var event = new MouseEvent('click', { 'view': window, 'bubbles': true, 'cancelable': true, 'clientX': "
				+ x + ", 'clientY': " + y + " });" + "document.dispatchEvent(event);";

		((JavascriptExecutor) driver).executeScript(script);
		SeatsPageObjects.boardingPoint.click();
		SeatsPageObjects.droppingPoint.click();
		SeatsPageObjects.proceedToBookButton.click();
	}

	public void enterPassengerDetails() {
		PageFactory.initElements(driver, PassengerDetailsPageObjects.class);
		
		PassengerDetailsPageObjects.name.sendKeys("Santhosh");
		PassengerDetailsPageObjects.gender.click();
		PassengerDetailsPageObjects.age.sendKeys("25");
		PassengerDetailsPageObjects.dropdown.click();
		PassengerDetailsPageObjects.dropdown.sendKeys("Pondicherry");
		
		PassengerDetailsPageObjects.stateOfResidence.click();
		PassengerDetailsPageObjects.mailId.sendKeys("abc@gmail.com");
		PassengerDetailsPageObjects.phoneNumber.sendKeys("9090909090");
		PassengerDetailsPageObjects.backArrow.click();
		PassengerDetailsPageObjects.clearAllFiltersButton.click();
	}
	
	public void setRating() {

		PageFactory.initElements(driver, FilterPageObjects.class);
		FilterPageObjects.rating.click();
		FilterPageObjects.seaterFilter.click();
		String busCount = FilterPageObjects.busCount.getText();
		System.out.println("Number of buses available : " + busCount);
		FilterPageObjects.viewSeats.click();
	}

	@Test
	public void busTicketBooking() {
		chooseLocation("Chennai");
		setFilterAndBusCount();
		seatSelection();
		enterPassengerDetails();

	}
	
	@Test
	public void highRatingBuses() {
		chooseLocation("Chennai");
		setRating();

	}
	
	@Test
	public void nilBuses() {
		chooseLocation("Lucknow");
		getBusCount();

	}
}
