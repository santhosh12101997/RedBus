package com.redbus.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SeatsPageObjects {

@FindBy(xpath="//*[@id='seatBpdp_undefined']/div/div[3]/div/div/div[2]/div[1]/div[2]/div[1]/div/ul/li[1]/div/div[1]/div")
public static WebElement boardingPoint;

@FindBy(xpath="//*[@id='seatBpdp_undefined']/div/div[3]/div/div/div[2]/div[1]/div[2]/div[2]/ul/li[1]/div[1]/div")
public static WebElement droppingPoint;

@FindBy(xpath="//button[contains(text(),'Proceed to book')]")
public static WebElement proceedToBookButton;
}

