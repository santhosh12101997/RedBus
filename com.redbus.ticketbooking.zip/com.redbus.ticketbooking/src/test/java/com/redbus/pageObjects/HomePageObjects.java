package com.redbus.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePageObjects {

@FindBy(id="src")
public static WebElement fromLocation;

@FindBy(id="dest")
public static WebElement toLocation;
	
@FindBy(className="labelCalendarContainer")
public static WebElement calender;

@FindBy(xpath="//span[text()='30']")
public static WebElement date;

@FindBy(id="search_button")
public static WebElement searchBusesButton;


@FindBy(xpath="//ul[@class='sc-dnqmqq eFEVtU']/li")
public static WebElement locationSelector;

}
