package com.redbus.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PassengerDetailsPageObjects {

@FindBy(id="seatno-04")
public static WebElement name;

@FindBy(id="div_22_0")
public static WebElement gender;

@FindBy(id="seatno-01")
public static WebElement age;

@FindBy(id="201")
public static WebElement dropdown;

@FindBy(xpath="//li[text()='Pondicherry']")
public static WebElement stateOfResidence;

@FindBy(id="seatno-05")
public static WebElement mailId;

@FindBy(id="seatno-06")
public static WebElement phoneNumber;

@FindBy(id="cust-info-back-arrow")
public static WebElement backArrow;

@FindBy(xpath="//button[contains(text(),'CLEAR ALL FILTERS')]")
public static WebElement clearAllFiltersButton;

}

