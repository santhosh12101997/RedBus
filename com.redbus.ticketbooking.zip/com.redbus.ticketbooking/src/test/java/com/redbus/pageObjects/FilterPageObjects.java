package com.redbus.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FilterPageObjects {

@FindBy(xpath="//input[@id='dtBefore 6 am']/following::label")
public static WebElement before6AMFilter;

@FindBy(xpath="//input[@id='bt_SEATER']/following::label")
public static WebElement seaterFilter;

@FindBy(xpath="//span[@class='f-bold busFound']")
public static WebElement busCount;

@FindBy(xpath="//div[@class='button view-seats fr']")
public static WebElement viewSeats;

@FindBy(xpath="//a[text()='Ratings']")
public static WebElement rating;

@FindBy(xpath="//*[@id='root']/div/div[2]/div/div/div")
public static WebElement noBus;

}

